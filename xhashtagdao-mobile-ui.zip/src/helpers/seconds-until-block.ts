export const secondsUntilBlock = (startBlock: number, endBlock: number) => {
    return endBlock - startBlock;
};
