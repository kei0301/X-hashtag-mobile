import React, { useState } from "react";
import "../../components/Header/wrap-button/wrap-button.scss";
import Wrap from "../../components/Wrap";

function WrapXTAG() {

    return (
        <div>
           <p>To Be Done</p>
        </div>

    );
}

export default WrapXTAG;
