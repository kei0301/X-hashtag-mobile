import "./comingsoon.scss";

function ComingSoon() {
    return (
        <div className="coming-soon-page">
            <p>Coming Soon</p>
        </div>
    );
}

export default ComingSoon;
