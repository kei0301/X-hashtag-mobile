import { IPendingTxn } from "./pending-txns-slice";
import { IAccountSlice } from "./account-slice";
import { IAppSlice } from "./app-slice";
import { IBondSlice } from "./bond-slice";
import { MessagesState } from "./messages-slice";
import { IWrapSlice } from "./wrap-slice";
import { IStakeState } from "./stake-slice";

export interface IReduxState {
    pendingTransactions: IPendingTxn[];
    account: IAccountSlice;
    app: IAppSlice;
    bonding: IBondSlice;
    stake: IStakeState;
    messages: MessagesState;
    wrapping: IWrapSlice;
}
